package com.example.form;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
    Button b1;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText text1 = (EditText) findViewById(R.id.editText);
        EditText text2 = (EditText) findViewById(R.id.editText2);
        final String name = text1.getText().toString();
        final String number = text1.getText().toString();

        b1 = (Button) findViewById(R.id.button);
        final ProgressBar progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);
        b1.setOnClickListener(new View.OnClickListener() {@Override
              public void onClick(View v) {

            if (true) {


                // visible the progress bar
                progressBar.setVisibility(View.VISIBLE);
                final Timer t = new Timer();
                TimerTask tt = new TimerTask() {
                    int counter = 0;

                    @Override
                    public void run() {
                        counter++;
                        progressBar.setProgress(counter);

                        if (counter == 100)
                            t.cancel();
                    }
                };

                t.schedule(tt, 0, 50);
            }
        }

    });
    }

}
